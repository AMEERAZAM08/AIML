# The-Hundred-Page-Machine-Learning-Book
This repository contains the draft PDF copies of the book: The 100 Page Machine Learning Book
